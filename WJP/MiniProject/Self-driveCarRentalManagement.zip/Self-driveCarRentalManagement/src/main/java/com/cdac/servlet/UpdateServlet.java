package com.cdac.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cdac.entity.Customer;
import com.cdac.helper.FactoryProvider;

/**
 * Servlet implementation class UpdateServlet
 */
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String name = request.getParameter("name");
			String age = request.getParameter("age");
			String car = request.getParameter("car");
			String category = request.getParameter("category");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String mobile = request.getParameter("mobile");
			
			
			int customerId=Integer.parseInt(request.getParameter("customerId"));
			
			Session session = FactoryProvider.getFactory().openSession();
			Transaction tx = session.beginTransaction();
			
			Customer customer=session.get(Customer.class, customerId);
			customer.setName(name);
			customer.setAge(age);
			customer.setCar(car);
			customer.setCategory(category);
			customer.setEmail(email);
			customer.setAddress(address);
			customer.setMobile(mobile);
			
			
			
			tx.commit();
			session.close();
			
			response.sendRedirect("customer-list.jsp");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	}


