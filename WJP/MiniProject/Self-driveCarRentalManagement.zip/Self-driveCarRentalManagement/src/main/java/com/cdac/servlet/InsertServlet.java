package com.cdac.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.CustomerDaoImpl;
import com.cdac.dao.Customerdao;
import com.cdac.entity.Customer;

/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String car = request.getParameter("car");
		String category = request.getParameter("category");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String mobile = request.getParameter("ph");
	
		
		
		Customer customer = new Customer(name,age,car,category,email,address,mobile);
		
		Customerdao customerDao=new CustomerDaoImpl();	
		int customerInserted = 0;
		customerInserted = customerDao.insertCustomer(customer);
		System.out.println("customer Inserted: "+customerInserted);
		
		RequestDispatcher rd = request.getRequestDispatcher("retrive");
		rd.forward(request, response);  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
