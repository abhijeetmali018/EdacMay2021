package com.cdac.dao;

import java.util.List;

import com.cdac.entity.Customer;

public interface Customerdao {
	public int insertCustomer(Customer customer);
	public boolean deleteCustomer(int id);
	public List<Customer> getAllCustomer();
	public boolean updateCustomer(int getId);
}
