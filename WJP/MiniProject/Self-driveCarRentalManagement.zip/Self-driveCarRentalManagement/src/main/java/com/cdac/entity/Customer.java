package com.cdac.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "id")
		private int id;
		
		@Column(name = "name")
		private String name;
		
		@Column(name = "age")
		private String age;
		
		@Column(name = "car")
		private String car;
		
		@Column(name = "category")
		private String category;
		
		@Column(name = "email")
		private String email;
		
		@Column(name = "address")
		private String address;
		
		@Column(name = "mobile")
		private String mobile;

		public Customer() {
			super();
			
		}

		public Customer(String name, String age, String car, String category, String email, String address,
				String mobile) {
			super();
			this.name = name;
			this.age = age;
			this.car = car;
			this.category = category;
			this.email = email;
			this.address = address;
			this.mobile = mobile;
		}

		public Customer(int id, String name, String age, String car, String category, String email, String address,
				String mobile) {
			super();
			this.id = id;
			this.name = name;
			this.age = age;
			this.car = car;
			this.category = category;
			this.email = email;
			this.address = address;
			this.mobile = mobile;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAge() {
			return age;
		}

		public void setAge(String age) {
			this.age = age;
		}

		public String getCar() {
			return car;
		}

		public void setCar(String car) {
			this.car = car;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
	

		

		
		
}
		
		
		

